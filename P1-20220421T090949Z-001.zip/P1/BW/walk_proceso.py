from snmp_library import *
from pysnmp.hlapi.asyncore import *
import time

def walk(OIDin,imp):

    #Version V1, un PDUs SNMP GET por objeto.
    version = 'v1' #Version SNMP
    community = 'public'
    ip_addr = '192.168.153.1' #Direccion IP mikrotik
    port = 161 #Puerto

    snmp_engine = snmp_requests(version, community, ip_addr, port)

    OIDini = str(OIDin) #OID para sacar las interfaces
    interfaces = []
    OIDis = OIDini.split('.')
    lentotal = len(OIDis)
    cerosfinal = 0
    i = lentotal-1

    #hago un for para calcular la longitud del OID inicial sin tener en cuenta los 0 del final.
    while int(OIDis[i]) == 0:
            cerosfinal = cerosfinal+1
            i = i-1

    lenini = lentotal - cerosfinal #longitud del OID inicial sin tener en cuenta los 0 del final

    OIDsig = '0'
    varBinds = [ObjectType(ObjectIdentity(OIDini))] #Creamos la variable varbind como hemos hecho en programas anteriores.

    t = time.time()

    mayor = True #variable auxiliar para el while

    while (mayor == True) and (OIDini != OIDsig):
        response = snmp_engine.snmpgetnext(varBinds)
        OIDsig = str(response.varBinds[0][0])
        OIDss = OIDsig.split('.')


        for i in range(lenini):
            if mayor == True:
                if int(OIDss[i])>int(OIDis[i]):
                    mayor = False
                else:
                    mayor = True

        #imprimimos la respuesta del getNext como en next_Moreno.py
        if mayor == True:
            if response.errorIndication:
                print 'errorIndication'
            elif response.errorStatus:
                print 'errorStatus'
            else:
                if imp == 1:
                    print response.varBinds[0]
                interfaces.append(OIDsig)
                varBinds = [ObjectType(ObjectIdentity(OIDsig))]

    return interfaces