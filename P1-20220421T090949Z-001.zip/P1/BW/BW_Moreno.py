from snmp_library import *
from pysnmp.hlapi.asyncore import *
import time
from walk_proceso import walk
import matplotlib.pyplot as plt
import numpy as np

#Version V1, un PDUs SNMP GET por objeto.
version = 'v1' #version SNMP
community = 'public' #public en get y getnext, private en set
ip_addr = '192.168.153.1' #direccion IP de Mikrotik
port = 161

snmp_engine = snmp_requests(version, community, ip_addr, port)

#hago un walk para ver las interfaces disponibles en el equipo
interfaces = walk('1.3.6.1.2.1.2.2.1.2',1) #interfaces del equipo de las que podemos extraer el ancho de banda

print "De que interfaz quieres obtener el ancho de banda, elige un numero"
elegido = ''
while (elegido != 1 and elegido !=2 and elegido != 3):
    elegido = input() #elige el interfaz, de momento asumo que coge bien el num.
    if (elegido > 3 or elegido == 0):
        print "esto no es una interfaz; elige otro numero"

#variables BW
#hago un walk para ver todos los BW de las interfaces disponibles, cogemos el BW del elegido por el usuario.
OIDbwin = walk('1.3.6.1.2.1.2.2.1.10',0)[elegido-1]  #OID BWin de la interfaz elegida
varBinds1 = [ObjectType(ObjectIdentity(OIDbwin))]  #varBinds de BWin
OIDbwout = walk('1.3.6.1.2.1.2.2.1.16',0)[elegido-1] #OID BWout de la interfaz elegida
varBinds2 = [ObjectType(ObjectIdentity(OIDbwout))] #varBinds de BWout
#Obtenemos el valor del BW
rin = snmp_engine.snmpget(varBinds1) #BWin inicial
rout = snmp_engine.snmpget(varBinds2) #BWout inicial

#variables para el tiempo
diftiempo = 0
OIDtup = '1.3.6.1.2.1.1.3.0'
varBinds3 = [ObjectType(ObjectIdentity(OIDtup))]
tup1 = snmp_engine.snmpget(varBinds3) #tiempo inicial
tini = tup1.varBinds[0][1]
rin1 = []
rout1 = []
tgraf = []
ttotal = 0

while ttotal < 60:
    #cada cuanto tiempo cogemos el ancho de banda
    time.sleep(3)
    #pasado el tiempo marcado anteriormente, volvemos a coger el valor del ancho de banda
    rin2 = snmp_engine.snmpget(varBinds1)
    rout2 = snmp_engine.snmpget(varBinds2)
    # asi como del tiempo
    tup2 = snmp_engine.snmpget(varBinds3)
    #calculamos el tiempo que llevamos calculando el ancho de banda, calculando el tiempo actual y restando el tiempo incial.
    ttotal = (tup2.varBinds[0][1] - tini) / 100
    #diferencia de tiempo entre el ultimo ancho de banda y el anterior para realizar el calculo posteriormente.
    diftiempo = (tup2.varBinds[0][1] - tup1.varBinds[0][1])/100
    tgraf.append(ttotal)

    #calculamos el ancho de banda con la diferencia del ultimo obtenido y el anterior y lo multiplicamos por 8 al ser octetos.
    rin1.append(((rin2.varBinds[0][1]-rin.varBinds[0][1])/diftiempo)*8)
    rout1.append(((rout2.varBinds[0][1]-rout.varBinds[0][1])/diftiempo)*8)

    #actualizo valores para poder seguir haciendo la diferencia del valor nuevo con el anterior
    rin = rin2
    rout = rout2
    tup1 = tup2


#Graficos
plt.subplot(2, 1, 1)
plt.plot(tgraf, rout1)
plt.title("BWout")
plt.subplot(2, 1, 2)
plt.plot(tgraf, rin1)
plt.title("BWin")
plt.show()