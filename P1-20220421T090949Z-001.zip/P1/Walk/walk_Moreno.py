from snmp_library import *
from pysnmp.hlapi.asyncore import *
import time

#Version V1, un PDUs SNMP GET por objeto.
version = 'v1' #Version SNMP
community = 'public'
ip_addr = '192.168.153.1' #Direccion IP mikrotik
port = 161 #Puerto

snmp_engine = snmp_requests(version, community, ip_addr, port)

OIDini = str('1.3.6.1.2.1.4.21.1.7.0') #OID del que queremos realizar el walk
OIDis = OIDini.split('.') #Separo el OID en cada punto para tener cada numero en una celda distinta y poder trabajar con el mas facil.
lentotal = len(OIDis) #longitud del OID
cerosfinal = 0
i = lentotal-1

#hago un for para calcular la longitud del OID inicial sin tener en cuenta los 0 del final.
while int(OIDis[i]) == 0:
        cerosfinal = cerosfinal+1
        i = i-1

lenini = lentotal - cerosfinal #longitud del OID inicial sin tener en cuenta los 0 del final

OIDsig = '0'
varBinds = [ObjectType(ObjectIdentity(OIDini))] #Creamos la variable varbind como hemos hecho en programas anteriores.

t = time.time()

mayor = True #variable auxiliar para el while
#Creo un while en el que ire realizando getnext hasta que el siguiente OID tenga la misma "profundidad" o llegue al final,
# donde devolveran el mismo OID cuando hagamos un getNext.
while (mayor == True) and (OIDini != OIDsig):
    response = snmp_engine.snmpgetnext(varBinds) #hacemos un getnext
    OIDsig = str(response.varBinds[0][0]) #obtenemos el OID de la respuesta del getNext
    OIDss = OIDsig.split('.') #lo separamos como hemos hecho con el primer OID

    #for para comparar el OID inicial y el nuevo OID, si se cumple una de las condiciones dichas antes cambiamos la variable
    #mayor a true para que pare el bucle while.
    for i in range(lenini):
        if mayor == True:
            if int(OIDss[i])>int(OIDis[i]):
                mayor = False
            else:
                mayor = True

    #imprimimos la respuesta del getNext como en next_Moreno.py
    if mayor == True:
        if response.errorIndication:
            print 'errorIndication'
        elif response.errorStatus:
            print 'errorStatus'
        else:
            print response.varBinds[0]
            varBinds = [ObjectType(ObjectIdentity(OIDsig))]

#ending time counter
elapsed = time.time() - t
print 'Total execution time: ' + str(elapsed) + ' seconds'