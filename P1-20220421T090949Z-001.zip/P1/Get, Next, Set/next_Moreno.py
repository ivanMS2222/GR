from snmp_library import *
from pysnmp.hlapi.asyncore import *
import time

version = 'v1'
community = 'public'
ip_addr = '192.168.153.1'
port = 161

snmp_engine = snmp_requests(version, community, ip_addr, port)
#vector de OID en este caso un valor menor que el queremos obtener ya que hacemos un getnext
OID = ['1.3.6.1.2.1.1','1.3.6.1.2.1.1.1.0','1.3.6.1.2.1.1.2.0','1.3.6.1.2.1.1.3.0','1.3.6.1.2.1.1.4.0','1.3.6.1.2.1.1.5.0','1.3.6.1.2.1.1.6.0']
t = time.time()

for i in OID:
    varBinds = [ObjectType(ObjectIdentity(i))]
    #Obtenemos el valor del siguiente OID mediante getnext
    response = snmp_engine.snmpgetnext(varBinds)

    if response.errorIndication:
        print 'errorIndication'
    elif response.errorStatus:
        print 'errorStatus'
    else:
        print response.varBinds[0]

#ending time counter
elapsed = time.time() - t
print 'Total execution time: ' + str(elapsed) + ' seconds'