from snmp_library import *
from pysnmp.hlapi.asyncore import *
import time

#Version V1, un PDUs SNMP GET por objeto.
version = 'v1' #version SNMP
community = 'public' #public en get y getnext, private en set
ip_addr = '192.168.153.1' #direccion IP de Mikrotik
port = 161

snmp_engine = snmp_requests(version, community, ip_addr, port)
#creo un vector con todos los OID que quiero analizar, estos OID los he obtenido mirando MIB Browser.
OID = ['1.3.6.1.2.1.1.1.0','1.3.6.1.2.1.1.2.0','1.3.6.1.2.1.1.3.0','1.3.6.1.2.1.1.4.0','1.3.6.1.2.1.1.5.0','1.3.6.1.2.1.1.6.0','1.3.6.1.2.1.1.7.0']
#el tiempo del programa empieza
t = time.time()

#recorro el vector OID y recorro el bucle para cada uno de estos.
for i in OID:
    #creamos la variable VarBinds cuyo parametro es nuestro OID casteado como ObjectIdentity
    varBinds = [ObjectType(ObjectIdentity(i))]
    #obtengo el get del actual varBind
    response = snmp_engine.snmpget(varBinds)

    if response.errorIndication:
        print 'errorIndication'
    elif response.errorStatus:
        print 'errorStatus'
    else:
        #imprimo por pantalla la posicion 0 del response que hemos obtenido anteriormente, en nuestro caso esta posicion se corresponde con los datos.
        print response.varBinds[0]

#ending time counter
elapsed = time.time() - t
print 'Total execution time: ' + str(elapsed) + ' seconds'

#Version V1, un PDUs SNMP GET para todos los objetos.
version = 'v1' #version SNMP
community = 'public' #public en get y getnext, private en set
ip_addr = '192.168.153.1' #direccion IP de Mikrotik
port = 161

snmp_engine = snmp_requests(version, community, ip_addr, port)

t = time.time()
#creamos un solo VarBinds con todos los OID
varBinds = [ObjectType(ObjectIdentity('1.3.6.1.2.1.1.1.0')), ObjectType(ObjectIdentity('1.3.6.1.2.1.1.2.0')),
            ObjectType(ObjectIdentity('1.3.6.1.2.1.1.3.0')), ObjectType(ObjectIdentity('1.3.6.1.2.1.1.4.0')),
            ObjectType(ObjectIdentity('1.3.6.1.2.1.1.5.0')), ObjectType(ObjectIdentity('1.3.6.1.2.1.1.6.0')),
            ObjectType(ObjectIdentity('1.3.6.1.2.1.1.7.0'))]
#Obtenemos la respuesta del varBind que sera el get para todos los OID que hayamos incluido en el
response = snmp_engine.snmpget(varBinds)
for i in [0, 1, 2, 3, 4, 5, 6]:
    if response.errorIndication:
        print 'errorIndication'
    elif response.errorStatus:
        print 'errorStatus'
    else:
        #imprimimos la respuesta
        print response.varBinds[i]

# ending time counter
elapsed = time.time() - t
print 'Total execution time: ' + str(elapsed) + ' seconds'

#Version V1 y V2c (lo cambio segun lo que quiera ver), un PDUs SNMP GET para todos los objetos con un OID incorrecto.
version = 'v2c' #version SNMP
community = 'public' #public en get y getnext, private en set
ip_addr = '192.168.153.1' #direccion IP de Mikrotik
port = 161

snmp_engine = snmp_requests(version, community, ip_addr, port)

t = time.time()
#igual que apartado anterior pero con un OID incorrecto
varBinds = [ObjectType(ObjectIdentity('1.3.6.1.2.1.1.1.0')), ObjectType(ObjectIdentity('1.3.6.1.2.1.1.2.0')),
            ObjectType(ObjectIdentity('1.3.6.1.2.1.1.10.0')), ObjectType(ObjectIdentity('1.3.6.1.2.1.1.4.0')),
            ObjectType(ObjectIdentity('1.3.6.1.2.1.1.5.0')), ObjectType(ObjectIdentity('1.3.6.1.2.1.1.6.0')),
            ObjectType(ObjectIdentity('1.3.6.1.2.1.1.7.0'))]
#igual que apartado anterior
response = snmp_engine.snmpget(varBinds)
#igual que apartado anterior
for i in [0, 1, 2, 3, 4, 5, 6]:
    if response.errorIndication:
        print 'errorIndication'
    elif response.errorStatus:
        print 'errorStatus'
    else:
        print response.varBinds[i]

# ending time counter
elapsed = time.time() - t
print 'Total execution time: ' + str(elapsed) + ' seconds'