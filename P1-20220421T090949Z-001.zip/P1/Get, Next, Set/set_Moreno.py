from snmp_library import *
from pysnmp.hlapi.asyncore import *
import time

version = 'v1'
community = 'torocuervo' #comunidad privada ya que queremos cambiar el valor del OID
ip_addr = '192.168.153.1'
port = 161

snmp_engine = snmp_requests(version, community, ip_addr, port)
#en este caso varBinds tiene dos parametros, el primero es el OID con el que queremos trabajar
#el segundo es el valor al que queremos cambiar el OID a traves del set.
varBinds = [ObjectType(ObjectIdentity('1.3.6.1.2.1.1.6.0'), OctetString('micasa'))]

t = time.time()

snmp_engine.snmpset(varBinds) #ejecutamos un snmpset para cambiar el valor del OID que queramos
comprobacion = snmp_engine.snmpget(varBinds)

if comprobacion.errorIndication:
    print 'errorIndication'
elif comprobacion.errorStatus:
    print 'errorStatus'
else:
    print comprobacion.varBinds[0]

#ending time counter
elapsed = time.time() - t
print 'Total execution time: ' + str(elapsed) + ' seconds'