from scapy.all import sr,srp,Ether,ARP,IP,TCP,conf,ICMP,sr1
from scapy.sendrecv import send
from snmp_library import *
from pysnmp.hlapi.asyncore import *

print "1 para hacer escaneo con ICMP, 0 para hacer escaneo con ARP"
seleccion = 4
#el cliente introduce por pantalla si quiere hacer escaneo de la red con ARP o ICMP, estara en un bucle
#hasta que meta un valor correcto
while (seleccion != 0) and (seleccion != 1):
    seleccion = input()
    if (seleccion != 0) and (seleccion != 1):
        print "Selecciona 1 o 0 porfavor"

    # Conf verb to 0
    conf.verb = 0
    version = 'v1'
    community = 'public'
    portsnmp = 161
    OID = '1.3.6.1.2.1.1.5'
    varBinds = [ObjectType(ObjectIdentity(OID))]
    ################################### ESCANEO RED ARP #######################################
                        ############# ESCANEO IPS CON ARP ###########
if seleccion == 0:
    ip_addr = []
    #creamos un paquete ARP
    request = ARP()
    #RED a la que vamos a querer enviar el paquete creado
    request.pdst = '192.168.153.0/24'
    #creamos un paquete Ethernet bloadcast para mandar el ARP a todos los equipos de la red
    broadcast = Ether()
    broadcast.dst = 'ff:ff:ff:ff:ff:ff'
    #combinamos el paquete Ethernet Broadcast con el paquete ARP request
    request_broadcast = broadcast / request
    #Enviamos el paquete a la red destino y capturamos la respuesta (direccion IP y MAC) de los diferentes equipos.
    #si responde la guardamos usamos la direccion IP si no no hacemos nada.
    clients = srp(request_broadcast, timeout=1)[0]
    for element in clients:
        #Imprimimos IP element[1].psrc y MAC element[1].hwsrc
        print "Equipo encontrado: " + element[1].psrc + "      " + element[1].hwsrc
        ipdst = IP(dst=element[1].psrc)
                         ############## ESCANEO PUERTOS ###########
        for port in [22,23,80,139,443]:
            #paquete TCP con puerto origen 5555 (aleatorio), puerto destino el que queremos ver si esta abierto
            # y flag SYN que explicare luego porque se usa.
            tcp = TCP(sport=5555, dport=port, flags="S")
            #Otro paquete TCP con flag RST
            tcpRst = TCP(sport=5555, dport=port, flags="R")
            #combinamos la direccion IP encontrada antes con el paquete TCP (syn) creado
            packet1 = ipdst / tcp
            packet_rst = ipdst / tcpRst
            #enviamos el SYN a la direccion IP deseada, sr1 recoge solo la primera respuesta
            ans = sr1(packet1, timeout=2)
            #Si recibimos una respuesta miramos con que FLAG nos ha respondido, al mandarle un SYN
            # nos podra responder con un SYN/ACK lo que significa que esta abierto o
            # con un RST lo que significa que esta cerrado
            if ans!=None:
                #flag 18 es SYN/ACK
                if ans[TCP].flags == 18:
                    print 'Puerto ' + str(port) + ': abierto'
                    #Mandamos un RST para confirmar la conexion (three-way handshake)
                    send(packet_rst)
                #flag 20 es RST
                elif ans[TCP].flags == 20:
                    print 'Puerto ' + str(port) + ': cerrado'
            #Si no recibimos nignuna respuesta es pq el puerto esta filtrado.
            else:
                print 'Puerto ' + str(port) + ': filtrado'

                         ############## SOPORTE SNMP ###########
        #Pedimos hacer un get a la direccion IP de la que queremos comprobar si soporta SNMP, podria ser un get,
        # get Next o cualquier cosa, solo queremos comprobar si recibimos una respuesta
        snmp_engine = snmp_requests(version, community, element[1].psrc, portsnmp)

        response = snmp_engine.snmpgetnext(varBinds)
        if response.errorIndication:
            print 'No soporta SNMP'
        elif response.errorStatus:
            print 'No soporta SNMP'
        else:
        #si recibimos una respuesta es pq soporta SNMP
            print "Soporta SNMP"

######################################### ESCANEO RED ICMP ##############################################
                          ############# ESCANEO IPS CON ICMP ###########
elif seleccion == 1:
    #IP que hemos comprobado con ARP que estan activas, si no tarda mucho en mandar todp
    for ipdst in ['192.168.153.1','192.168.153.253','192.168.153.254','192.168.153.20']:
    #combinamos el paquete IP con uno ICMP
        ans = sr1(IP(dst=ipdst)/ICMP(), timeout=1)
        if ans != None:
            #Si recibimos una respuesta al PING que hemos mandado es porque el equipo esta activo,
            #si el equipo esta activo hacemos el escaneo de puertos y soporte SNMP igual que antes.
            print "Equipo " + ans[IP].src + " encontrado"
            ############## ESCANEO PUERTOS ###########
            for port in [22, 23, 80, 139, 443]:

                tcp = TCP(sport=5555, dport=port, flags="S")
                tcpRst = TCP(sport=5555, dport=port, flags="R")
                packet1 = IP(dst=ipdst) / tcp
                packet_rst = IP(dst=ipdst) / tcpRst
                ans = sr1(packet1, timeout=2)
                if ans != None:
                    if ans[TCP].flags == 18:
                        print 'Puerto ' + str(port) + ': abierto'
                        send(packet_rst)
                    elif ans[TCP].flags == 20:
                        print 'Puerto ' + str(port) + ': cerrado'
                else:
                    print 'Puerto ' + str(port) + ': filtrado'
                ############## SOPORTE SNMP ###########

            snmp_engine = snmp_requests(version, community, ipdst, portsnmp)

            response = snmp_engine.snmpgetnext(varBinds)
            if response.errorIndication:
                print 'No soporta SNMP'
            elif response.errorStatus:
                print 'No soporta SNMP'
            else:
                print "Soporta SNMP"
        else:
            print "Equipo " + ipdst + " no encontrado"
