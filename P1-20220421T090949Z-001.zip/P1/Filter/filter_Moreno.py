import smtplib
from email.mime import multipart
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from snmp_library import *
from pysnmp.hlapi.asyncore import *
import time
from walk_proceso import walk
import matplotlib.pyplot as plt
import numpy as np

#capturar en interfaz eth0

version = 'v1' #version SNMP
community = 'public'
ip_addr = '192.168.153.253' #direccion IP de Mikrotik
port = 161
snmp_engine = snmp_requests(version, community, ip_addr, port)

#funcion SET SNMP
def set(OID, OctetString):
    varBinds = [ObjectType(ObjectIdentity(OID), OctetString)]
    snmp_engine.snmpset(varBinds)

#funcion GET SNMP
def get(OID):
    varBinds = [ObjectType(ObjectIdentity(OID))]
    response = snmp_engine.snmpget(varBinds)
    return response

############################################# CONF GRUPO FILTER ##################################################
def Filter(inst, vect):
    set('1.3.6.1.2.1.16.7.1.1.11.' + str(inst), Integer32(4)) # Borramos filtros anteriormente creados
    set('1.3.6.1.2.1.16.7.1.1.11.'+ str(inst), Integer32(2)) # Under creation, mientras este en este modo modificamos lo correspondiente al filtro
    set('1.3.6.1.2.1.16.7.1.1.2.' + str(inst), vect[0]) # canal al que se va a aplicar el filtro
    set('1.3.6.1.2.1.16.7.1.1.3.' + str(inst), vect[1]) # offset desde el que queremos empezar a comparar con el filtro
    set('1.3.6.1.2.1.16.7.1.1.4.' + str(inst), vect[2]) # filterPktData, valor con el que vamos a comparar en el filtro
    set('1.3.6.1.2.1.16.7.1.1.5.' + str(inst), vect[3]) # filterPktDataMask, mascara que aplicamos al filtro los bits que correspondan con estas seran los que se sigan comparando mas tarde.
    set('1.3.6.1.2.1.16.7.1.1.6.' + str(inst), vect[4]) # filterPktDataNotMask, The inversion mask that is applied to the match process.
    set('1.3.6.1.2.1.16.7.1.1.7.' + str(inst), Integer32(0)) # filterPktStatus
    set('1.3.6.1.2.1.16.7.1.1.8.' + str(inst), Integer32(7)) # filterPktStatusMask
    set('1.3.6.1.2.1.16.7.1.1.9.' + str(inst), Integer32(0)) # filterPktStatusNotMask
    set('1.3.6.1.2.1.16.7.1.1.10.' + str(inst), OctetString("Ivan")) #Owner
    set('1.3.6.1.2.1.16.7.1.1.11.' + str(inst), Integer32(1)) # Ya hemos terminado de configurar el filtro por lo que lo ponemos a 1 para activarlo.

## DNS ## para DNS voy a comparar que el puerto dst u origen sean el 53.
filtroDNS1 = [Integer32(100), Integer32(34), OctetString(hexValue="0035"), OctetString(hexValue="FFFF"), OctetString(hexValue="0000")]
Filter(100, filtroDNS1)
filtroDNS2 = [Integer32(100), Integer32(36), OctetString(hexValue="0035"), OctetString(hexValue="FFFF"), OctetString(hexValue="0000")]
Filter(101, filtroDNS2)

## HTTPS ## para HTTPS voy a comparar que el puerto dst u origen sean el 443.
filtroHTTPS1 = [Integer32(200), Integer32(34), OctetString(hexValue="01bb"), OctetString(hexValue="FFFF"), OctetString(hexValue="0000")]
Filter(200, filtroHTTPS1)
filtroHTTPS2 = [Integer32(200), Integer32(36), OctetString(hexValue="01bb"), OctetString(hexValue="FFFF"), OctetString(hexValue="0000")]
Filter(201, filtroHTTPS2)

## ICMP ## para ICMP voy a comparar que el campo PROTOCOL de la trama sea 01 que se corresponde a ICMP
filtroICMP1 = [Integer32(300), Integer32(23), OctetString(hexValue="01"), OctetString(hexValue="FF"), OctetString(hexValue="00")]
Filter(300, filtroICMP1)

######################################### CONF GRUPO CHANNEL ####################################################

def Channel(inst):
    set('1.3.6.1.2.1.16.7.2.1.12.' + str(inst), Integer32(4)) # Borramos canales anteriormente creados
    set('1.3.6.1.2.1.16.7.2.1.12.' + str(inst), Integer32(2)) # Under creation, mientras este en este modo modificamos lo correspondiente al canal
    set('1.3.6.1.2.1.16.7.2.1.2.' + str(inst),Integer32(2)) # channelIfIndex
    set('1.3.6.1.2.1.16.7.2.1.3.' + str(inst), Integer32(1)) # channelAcceptType, si esta en 1 el canal acepta paquetes que sean aceptados
    # por el packet data y el packet status matches del filtro asociado, si esta en 2 acepta si uno de los dos no acepta el paquete.
    set('1.3.6.1.2.1.16.7.2.1.4.' + str(inst), Integer32(1)) # channelDataControl, si ponemos 1 estara permitido el flujo de datos por el canal y si ponemos 2 no
    set('1.3.6.1.2.1.16.7.2.1.10.' + str(inst), OctetString("Canal")) # channelDescription
    set('1.3.6.1.2.1.16.7.2.1.11.' + str(inst), OctetString("Ivan")) # Owner
    set('1.3.6.1.2.1.16.7.2.1.12.' + str(inst), Integer32(1)) # Ya hemos terminado de configurar el canal por lo que lo ponemos a 1 para activarlo.

Channel(100) #DNS
Channel(200) #HTTPS
Channel(300) #ICMP

######################################## CORREO ELECTRONICO ###############################################

def correo(message):
    # create message object instance
    msg = MIMEMultipart()
    # setup the parameters of the message
    password = "your_password"
    msg['From'] = "774990@unizar.es"
    msg['To'] = "774990@unizar.es"
    msg['Subject'] = "Numero de paq"
    # add in the message body
    msg.attach(MIMEText(message, 'plain'))
    # create server
    server = smtplib.SMTP('smtp.gmail.com: 587')
    server.starttls()
    # Login Credentials for sending the mail
    server.login(msg['From'], password)
    # send the message via the server.
    server.sendmail(msg['From'], msg['To'], msg.as_string())
    server.quit()

#Procedimiento similar al que hicimos en el BW.
diftiempo = 0
tup1 = get('1.3.6.1.2.1.1.3.0').varBinds[0][1] #tiempo inicial
tini = tup1
channelMatchesDNS = get('1.3.6.1.2.1.16.7.2.1.9.100').varBinds[0][1] #paquetes iniciales DNS
channelMatchesHTTPS = get('1.3.6.1.2.1.16.7.2.1.9.200').varBinds[0][1] #paquetes iniciales HTTPS0
channelMatchesICMP = get('1.3.6.1.2.1.16.7.2.1.9.300').varBinds[0][1] #paquetes iniciales ICMP
DNS = []
HTTPS = []
ICMP = []
tgraf = []
ttotal = 0

while ttotal < 60:
    #cada cuanto tiempo cogemos el numero de paquetes
    time.sleep(3)
    #pasado el tiempo marcado anteriormente, volvemos a coger el valor del numero de paquetes
    channelMatchesDNSsig = get('1.3.6.1.2.1.16.7.2.1.9.100').varBinds[0][1] #paquetes sig
    channelMatchesHTTPSsig = get('1.3.6.1.2.1.16.7.2.1.9.200').varBinds[0][1]  # paquetes sig
    channelMatchesICMPsig = get('1.3.6.1.2.1.16.7.2.1.9.300').varBinds[0][1]  # paquetes sig
    # asi como del tiempo
    tup2 = get('1.3.6.1.2.1.1.3.0').varBinds[0][1]
    #calculamos el tiempo que llevamos calculando el n de paquetes, calculando el tiempo actual y restando el tiempo incial.
    ttotal = (tup2 - tini) / 100
    #diferencia de tiempo entre el ultimo numero de paq y el anterior para realizar el calculo posteriormente.
    diftiempo = (tup2 - tup1)/100
    tgraf.append(ttotal)
    print 'ttotal' + str(ttotal)

    #calculamos el num de paquetes en los ultimos segundos.
    DNS.append(int(channelMatchesDNSsig) - int(channelMatchesDNS))
    HTTPS.append(int(channelMatchesHTTPSsig) - int(channelMatchesHTTPS))
    ICMP.append(int(channelMatchesICMPsig) - int(channelMatchesICMP))
    #actualizo valores para poder seguir haciendo la diferencia del valor nuevo con el anterior
    channelMatchesDNS = channelMatchesDNSsig
    channelMatchesHTTPS = channelMatchesHTTPSsig
    channelMatchesICMP = channelMatchesICMPsig
    tup1 = tup2

#Enviamos el correo con el num de paquetes filtrados.
message = "Paquetes DNS: " + str(sum(DNS)) + ", Paquetes HTTPS: " + str(sum(HTTPS)) + ", Paquetes ICMP: " + str(sum(ICMP))
correo(message)

#Graficos
plt.subplot(3, 1, 1)
plt.plot(tgraf, DNS)
plt.title("Trafico DNS")
plt.subplot(3, 1, 2)
plt.plot(tgraf, HTTPS)
plt.title("Trafico HTTPS")
plt.subplot(3, 1, 3)
plt.plot(tgraf, ICMP)
plt.title("Trafico ICMP")
plt.show()

